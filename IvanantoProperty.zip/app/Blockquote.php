<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Blockquote extends Model
{
    //
    protected $fillable = [
        'value'
        
    ];

    public $timestamps = false;
}
