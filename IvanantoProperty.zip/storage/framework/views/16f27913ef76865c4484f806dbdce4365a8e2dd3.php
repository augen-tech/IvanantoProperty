<?php $__env->startSection('breadcumb'); ?>
<div class="row page-titles">
    <div class="col-md-5 col-8 align-self-center">
        <h3 class="text-themecolor m-b-0 m-t-0">Benefit Edit</h3>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-12">
        <!-- <div class="card"> -->
            <div class="card card-body">
                <!-- <h4 class="card-title">Benefit</h4> -->
                
                <form  action="<?php echo e(route('admin.benefit.update', $benefit->id)); ?>"  method="POST">
                    <div class="form-group">                        
                        <label>Title</label>
                        <textarea name="title" class="form-control" rows="1" required><?php echo e($benefit->title); ?></textarea>
                        <br>
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="5" required><?php echo e($benefit->description); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-block btn-sml btn-success">Edit</button>
                </form>       
            </div>
        <!-- </div> -->
    </div>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IvanantoProperty\resources\views/admin/benefit/edit.blade.php ENDPATH**/ ?>