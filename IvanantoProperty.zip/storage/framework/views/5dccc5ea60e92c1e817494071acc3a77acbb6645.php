<?php $__env->startSection('breadcumb'); ?>
<div class="row page-titles">
    <div class="col-md-5 col-8 align-self-center">
        <h3 class="text-themecolor m-b-0 m-t-0">FAQ List</h3>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
 <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!-- <h4 class="card-title">Data Export</h4> -->
                                <!-- <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6> -->
                                <div class="table-responsive m-t-40">
                                    <table id="myTable" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th>Question</th>
                                                <th>Answer</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        
                                        <tbody>
                                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index+1); ?></td>
                                                <td><?php echo e($row->question); ?></td>
                                                <td><?php echo e($row->answer); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.faq.edit', $row->id)); ?>">
                                                        <span><i class="mdi mdi-lead-pencil"></i></span>          
                                                    </a> 
                                                    <a href="<?php echo e(route('admin.faq.destroy', $row->id)); ?>">
                                                        <span><i class="mdi mdi-delete"></i></span>          
                                                    </a>  
                                                </td>
                                            </tr> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <!-- This is data table -->
    <script src="<?php echo e(asset('material/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script>$('#myTable').DataTable();</script>

    <!-- Style switcher -->
    <!-- ============================================================== -->
    <script src="<?php echo e(asset('material/plugins/styleswitcher/jQuery.style.switcher.js')); ?>"></script>

    
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IvanantoProperty\resources\views/admin/faq/index.blade.php ENDPATH**/ ?>