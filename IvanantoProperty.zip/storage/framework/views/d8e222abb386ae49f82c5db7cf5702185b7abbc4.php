<?php $__env->startSection('breadcumb'); ?>
<div class="row page-titles">
    <div class="col-md-5 col-8 align-self-center">
        <h3 class="text-themecolor m-b-0 m-t-0">FAQ Edit</h3>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-12">
        <!-- <div class="card"> -->
            <div class="card card-body">
                <!-- <h4 class="card-title">Benefit</h4> -->
                
                <form  action="<?php echo e(route('admin.faq.update', $faq->id)); ?>"  method="POST">
                    <div class="form-group">                        
                        <label>Answer</label>
                        <textarea required name="question" class="form-control" rows="1" ><?php echo e($faq->question); ?></textarea>
                        <br>
                        <label>Description</label>
                        <textarea required name="answer" class="form-control" rows="5"><?php echo e($faq->answer); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-block btn-sml btn-success">Edit</button>
                </form>       
            </div>
        <!-- </div> -->
    </div>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IvanantoProperty\resources\views/admin/faq/edit.blade.php ENDPATH**/ ?>