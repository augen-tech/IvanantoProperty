<?php $__env->startSection('breadcumb'); ?>
<div class="row page-titles">
    <div class="col-md-5 col-8 align-self-center">
        <h3 class="text-themecolor m-b-0 m-t-0">Blockquote Edit</h3>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form class="form-material m-t-0" action="<?php echo e(route('admin.blockquote.update', $blockquote->id)); ?>"  method="POST">
                    <div class="form-group">
                        <!-- <label>Type Below</label> -->
                        <textarea name="value" class="form-control" rows="5" required><?php echo e($blockquote->value); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-block btn-sml btn-success">Edit</button>
                </form>       
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\IvanantoProperty\resources\views/admin/blockquote/edit.blade.php ENDPATH**/ ?>